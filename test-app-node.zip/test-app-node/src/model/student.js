const students = [
  {
    name: "Muhammad",
  },
  {
    name: "Nabeel",
  },
  {
    name: "Mubara",
  },
];

const studentModal = {
  getAll: () => {
    return students;
  },
};

export default studentModal;
